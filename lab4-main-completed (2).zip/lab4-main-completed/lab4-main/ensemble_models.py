"""Эксперимент с ансамблем или полносвязной нейронной сетью."""
from __future__ import annotations

import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)

from grader_contracts.ensembles import EnsembleInput, EnsembleResult


def run_ensemble_experiment(data: EnsembleInput) -> EnsembleResult:
    """Обучает случайный лес на train и оценивает его на test."""
    model = RandomForestClassifier(
        n_estimators=300,
        max_depth=8,
        min_samples_leaf=3,
        max_features="sqrt",
        class_weight="balanced",
        random_state=data.random_seed,
        n_jobs=-1,
    )

    model.fit(data.train_features, data.train_target)

    positive_class_index = list(model.classes_).index(1)
    probabilities = model.predict_proba(data.test_features)[:, positive_class_index]
    predictions = (probabilities >= 0.5).astype(int)

    return EnsembleResult(
        model_name="Random Forest (300 деревьев, max_depth=8)",
        probabilities=probabilities,
        predictions=predictions,
        roc_auc=float(roc_auc_score(data.test_target, probabilities)),
        accuracy=float(accuracy_score(data.test_target, predictions)),
        precision=float(precision_score(data.test_target, predictions, zero_division=0)),
        recall=float(recall_score(data.test_target, predictions, zero_division=0)),
        f1=float(f1_score(data.test_target, predictions, zero_division=0)),
    )
